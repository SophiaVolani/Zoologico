from pony.orm import Required
from src.config import db

class Registro(db.Entity):
    descricao = Required(str)
    data = Required(str)

    animal = Required("Animal")
    produto = Required("Produto")
    zoologico = Required("Zoologico")
