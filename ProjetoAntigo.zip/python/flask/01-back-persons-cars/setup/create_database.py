from src.config import *
from src.model.animal import *
from src.model.zoologico import *
from src.model.registro import *
from src.model.produto import *
from src.model.fornecedor_alimentos import *

# Create the tables in the database
with app.app_context():
    db.create_all()

print("Database created")