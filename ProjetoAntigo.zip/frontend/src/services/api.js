import axios from 'axios'


const api = axios.create({
    baseURL: 'http://localhost:5000', // ajuste a URL/porta do seu backend
    headers: {
        'Content-Type': 'application/json',
    }
})


export default api