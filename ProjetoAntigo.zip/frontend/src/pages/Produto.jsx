import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Produto() {
    const API_URL = "http://localhost:5000";

    const [produtos, setProdutos] = useState([]);
    const [form, setForm] = useState({
        id: "",
        nome: "",
        tipo: "",
        quantidade: ""
    });

    useEffect(() => {
        loadProdutos();
    }, []);

    async function loadProdutos() {
        try {
            const res = await fetch(`${API_URL}/produtos`);
            const data = await res.json();
            setProdutos(data.dados || []);
        } catch {
            console.error("Erro ao carregar produtos");
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();

        const method = form.id ? "PUT" : "POST";

        const url = form.id
            ? `${API_URL}/produtos/${form.id}`
            : `${API_URL}/produtos`;

        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(form)
        });

        setForm({ id: "", nome: "", tipo: "", quantidade: "" });
        loadProdutos();
    }

    function handleEdit(prod) {
        setForm(prod);
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    async function handleDelete(id) {
        if (!window.confirm("Excluir produto?")) return;

        await fetch(`${API_URL}/produtos/${id}`, { method: "DELETE" });
        loadProdutos();
    }

    return (
        <>
            <style>{`
                * { margin: 0; padding: 0; box-sizing: border-box; }
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                }
                .navbar {
                    background: white;
                    padding: 15px 30px;
                    border-radius: 10px;
                    margin-bottom: 30px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                }
                .navbar a {
                    color: #667eea;
                    text-decoration: none;
                    font-weight: bold;
                    padding: 8px 15px;
                    border-radius: 5px;
                    transition: background 0.3s;
                }
                .navbar a:hover { background: #f0f0f0; }
                .container { max-width: 1200px; margin: 0 auto; }
                .card {
                    background: white;
                    border-radius: 15px;
                    padding: 30px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    margin-bottom: 30px;
                }
                h1 {
                    color: #667eea;
                    margin-bottom: 30px;
                }
                .form-group { margin-bottom: 20px; }
                label { display: block; margin-bottom: 8px; color: #333; font-weight: 500; }
                input, select {
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                    font-size: 1em;
                }
                input:focus, select:focus {
                    outline: none;
                    border-color: #667eea;
                }
                .btn {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 1em;
                    font-weight: bold;
                    transition: 0.3s;
                }
                .btn:hover {
                    transform: translateY(-2px);
                    box-shadow: 0 5px 15px rgba(102, 126, 234, 0.4);
                }
                .btn-edit {
                    background: #f093fb;
                    padding: 8px 15px;
                    font-size: 0.9em;
                    color: white;
                }
                .btn-delete {
                    background: #fa709a;
                    padding: 8px 15px;
                    font-size: 0.9em;
                    color: white;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                    margin-top: 20px;
                }
                th, td {
                    padding: 15px;
                    text-align: left;
                    border-bottom: 1px solid #e0e0e0;
                }
                th {
                    background: #f8f9fa;
                    color: #667eea;
                    font-weight: 600;
                }
                tr:hover { background: #f8f9fa; }
                .actions {
                    display: flex;
                    gap: 10px;
                }
            `}</style>

            {/* NAVBAR */}
            <div className="navbar">
                <Link to="/">🏠 Início</Link>
                <div>
                    <Link to="/zoologico">Zoológicos</Link>
                    <Link to="/animal">Animais</Link>
                    <Link to="/fornecedor_alimento">Fornecedores</Link>
                    <Link to="/registro">Registros</Link>
                </div>
            </div>

            <div className="container">
                {/* FORM */}
                <div className="card">
                    <h1>📦 Gerenciamento de Produtos</h1>

                    <form onSubmit={handleSubmit}>
                        <input type="hidden" value={form.id} />

                        <div className="form-group">
                            <label>Nome *</label>
                            <input
                                required
                                value={form.nome}
                                onChange={(e) =>
                                    setForm({ ...form, nome: e.target.value })
                                }
                            />
                        </div>

                        <div className="form-group">
                            <label>Tipo *</label>
                            <select
                                required
                                value={form.tipo}
                                onChange={(e) =>
                                    setForm({ ...form, tipo: e.target.value })
                                }
                            >
                                <option value="">Selecione...</option>
                                <option value="Ração">Ração</option>
                                <option value="Natural">Natural</option>
                            </select>
                        </div>

                        <div className="form-group">
                            <label>Quantidade *</label>
                            <input
                                type="number"
                                required
                                value={form.quantidade}
                                onChange={(e) =>
                                    setForm({ ...form, quantidade: e.target.value })
                                }
                            />
                        </div>

                        <button className="btn">
                            {form.id ? "Atualizar Produto" : "Cadastrar Produto"}
                        </button>
                    </form>
                </div>

                {/* TABELA */}
                <div className="card">
                    <h2>Lista de Produtos</h2>

                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Tipo</th>
                                <th>Quantidade</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            {produtos.length === 0 ? (
                                <tr>
                                    <td colSpan="5" style={{ textAlign: "center" }}>
                                        Nenhum produto cadastrado
                                    </td>
                                </tr>
                            ) : (
                                produtos.map((p) => (
                                    <tr key={p.id}>
                                        <td>{p.id}</td>
                                        <td>{p.nome}</td>
                                        <td>{p.tipo}</td>
                                        <td>{p.quantidade}</td>

                                        <td className="actions">
                                            <button
                                                className="btn-edit"
                                                onClick={() => handleEdit(p)}
                                            >
                                                Editar
                                            </button>

                                            <button
                                                className="btn-delete"
                                                onClick={() => handleDelete(p.id)}
                                            >
                                                Excluir
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
}
