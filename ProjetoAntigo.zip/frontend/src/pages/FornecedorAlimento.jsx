import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function FornecedorAlimento() {
    const API_URL = "http://localhost:5000";

    const [fornecedores, setFornecedores] = useState([]);
    const [produtos, setProdutos] = useState([]);

    const [form, setForm] = useState({
        id: "",
        nome: "",
        cnpj: "",
        produto: ""
    });

    // Carregar fornecedores e produtos ao iniciar
    useEffect(() => {
        loadFornecedores();
        loadProdutos();
    }, []);

    async function loadProdutos() {
        try {
            const res = await fetch(`${API_URL}/produtos`);
            const data = await res.json();
            setProdutos(data.dados || []);
        } catch {
            console.error("Erro ao carregar produtos");
        }
    }

    async function loadFornecedores() {
        try {
            const res = await fetch(`${API_URL}/fornecedores`);
            const data = await res.json();
            setFornecedores(data.dados || []);
        } catch {
            console.error("Erro ao carregar fornecedores");
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();

        const method = form.id ? "PUT" : "POST";

        const url = form.id
            ? `${API_URL}/fornecedores/${form.id}`
            : `${API_URL}/fornecedores`;

        const payload = {
            nome: form.nome,
            cnpj: form.cnpj,
            produto: parseInt(form.produto),
        };

        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify(payload)
        });

        setForm({ id: "", nome: "", cnpj: "", produto: "" });
        loadFornecedores();
    }

    function handleEdit(f) {
        setForm({
            id: f.id,
            nome: f.nome,
            cnpj: f.cnpj,
            produto: f.produto ? f.produto.id : ""
        });
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    async function handleDelete(id) {
        if (!window.confirm("Deseja excluir este fornecedor?")) return;

        await fetch(`${API_URL}/fornecedores/${id}`, { method: "DELETE" });
        loadFornecedores();
    }

    return (
        <>
            <style>{`
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                }
                .navbar {
                    background: white;
                    padding: 15px 30px;
                    border-radius: 10px;
                    margin-bottom: 30px;
                    display: flex;
                    justify-content: space-between;
                    align-items: center;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                }
                .navbar a {
                    color: #667eea;
                    text-decoration: none;
                    font-weight: bold;
                    padding: 8px 15px;
                    border-radius: 5px;
                    transition: background 0.3s;
                }
                .navbar a:hover { background: #f0f0f0; }
                .container { max-width: 1200px; margin: 0 auto; }
                .card {
                    background: white;
                    border-radius: 15px;
                    padding: 30px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    margin-bottom: 30px;
                }
                h1, h2 {
                    color: #667eea;
                    margin-bottom: 25px;
                }
                .form-group { margin-bottom: 20px; }
                label {
                    display: block;
                    margin-bottom: 8px;
                    color: #333;
                    font-weight: 500;
                }
                input, select {
                    width: 100%;
                    padding: 12px;
                    border: 2px solid #e0e0e0;
                    border-radius: 8px;
                }
                input:focus, select:focus {
                    border-color: #667eea;
                    outline: none;
                }
                .btn {
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    color: white;
                    border: none;
                    padding: 12px 30px;
                    border-radius: 8px;
                    cursor: pointer;
                    font-size: 1em;
                    font-weight: bold;
                    margin-right: 10px;
                }
                .btn-edit {
                    background: #f093fb;
                    padding: 8px 15px;
                    color: white;
                }
                .btn-delete {
                    background: #fa709a;
                    padding: 8px 15px;
                    color: white;
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    padding: 15px;
                    border-bottom: 1px solid #ddd;
                }
                th {
                    background: #f8f9fa;
                }
                tr:hover {
                    background: #f1f1f1;
                }
                .actions {
                    display: flex;
                    gap: 10px;
                }
            `}</style>

            {/* NAVBAR */}
            <div className="navbar">
                <Link to="/">🏠 Início</Link>
                <div>
                    <Link to="/zoologico">Zoológicos</Link>
                    <Link to="/animal">Animais</Link>
                    <Link to="/produto">Produtos</Link>
                    <Link to="/registro">Registros</Link>
                </div>
            </div>

            <div className="container">
                {/* FORMULÁRIO */}
                <div className="card">
                    <h1>🚚 Gerenciamento de Fornecedores</h1>

                    <form onSubmit={handleSubmit}>
                        <input type="hidden" value={form.id} />

                        <div className="form-group">
                            <label>Nome do Fornecedor *</label>
                            <input
                                required
                                value={form.nome}
                                onChange={(e) => setForm({ ...form, nome: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>CNPJ *</label>
                            <input
                                required
                                maxLength="18"
                                value={form.cnpj}
                                onChange={(e) => setForm({ ...form, cnpj: e.target.value })}
                            />
                        </div>

                        <div className="form-group">
                            <label>Produto *</label>
                            <select
                                required
                                value={form.produto}
                                onChange={(e) => setForm({ ...form, produto: e.target.value })}
                            >
                                <option value="">Selecione um produto...</option>

                                {produtos.map((p) => (
                                    <option key={p.id} value={p.id}>
                                        {p.nome} ({p.tipo})
                                    </option>
                                ))}
                            </select>
                        </div>

                        <button className="btn">
                            {form.id ? "Atualizar" : "Cadastrar"}
                        </button>
                    </form>
                </div>

                {/* LISTA */}
                <div className="card">
                    <h2>Lista de Fornecedores</h2>

                    <table>
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>CNPJ</th>
                                <th>Produto</th>
                                <th>Ações</th>
                            </tr>
                        </thead>

                        <tbody>
                            {fornecedores.length === 0 ? (
                                <tr>
                                    <td colSpan="5" style={{ textAlign: "center" }}>
                                        Nenhum fornecedor cadastrado
                                    </td>
                                </tr>
                            ) : (
                                fornecedores.map((f) => (
                                    <tr key={f.id}>
                                        <td>{f.id}</td>
                                        <td>{f.nome}</td>
                                        <td>{f.cnpj}</td>
                                        <td>{f.produto ? f.produto.nome : "N/A"}</td>

                                        <td className="actions">
                                            <button
                                                className="btn-edit"
                                                onClick={() => handleEdit(f)}
                                            >
                                                Editar
                                            </button>

                                            <button
                                                className="btn-delete"
                                                onClick={() => handleDelete(f.id)}
                                            >
                                                Excluir
                                            </button>
                                        </td>
                                    </tr>
                                ))
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </>
    );
}
