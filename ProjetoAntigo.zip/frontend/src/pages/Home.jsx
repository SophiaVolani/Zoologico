import React from "react";
import { Link } from "react-router-dom";

export default function Home() {
    return (
        <>
            <style>{`
                body {
                    font-family: 'Segoe UI', Tahoma, Geneva, Verdana, sans-serif;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    margin: 0;
                    padding: 20px;
                }
                .container {
                    max-width: 900px;
                    margin: auto;
                }
                .card {
                    background: white;
                    padding: 40px;
                    border-radius: 15px;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.2);
                    text-align: center;
                }
                h1 {
                    color: #667eea;
                    margin-bottom: 20px;
                }
                p {
                    font-size: 18px;
                    color: #444;
                    margin-bottom: 30px;
                }
                .menu {
                    display: flex;
                    flex-direction: column;
                    gap: 15px;
                    margin-top: 20px;
                }
                .menu a {
                    display: block;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    padding: 12px;
                    color: white;
                    text-decoration: none;
                    font-weight: bold;
                    border-radius: 8px;
                    transition: 0.3s;
                }
                .menu a:hover {
                    transform: translateY(-3px);
                    box-shadow: 0 6px 18px rgba(0,0,0,0.25);
                }
            `}</style>

            <div className="container">
                <div className="card">
                    <h1>🐾 Sistema do Zoológico</h1>
                    <p>Escolha abaixo o que deseja gerenciar:</p>

                    <div className="menu">
                        <Link to="/zoologico">🏛️ Gerenciar Zoológicos</Link>
                        <Link to="/animal">🐆 Gerenciar Animais</Link>
                        <Link to="/produto">📦 Gerenciar Produtos</Link>
                        <Link to="/fornecedor_alimento">🥫 Gerenciar Fornecedores</Link>
                        <Link to="/registro">📝 Gerenciar Registros</Link>
                    </div>
                </div>
            </div>
        </>
    );
}
