import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Registro() {
    const API_URL = "http://localhost:5000";

    const [registros, setRegistros] = useState([]);
    const [animais, setAnimais] = useState([]);
    const [zoologicos, setZoologicos] = useState([]);

    const [form, setForm] = useState({
        id: "",
        descricao: "",
        data: "",
        animal: "",
        zoologico: ""
    });

    useEffect(() => {
        loadRegistros();
        loadAnimais();
        loadZoologicos();
    }, []);

    async function loadRegistros() {
        const res = await fetch(`${API_URL}/registros`);
        const data = await res.json();
        setRegistros(data.dados || []);
    }

    async function loadAnimais() {
        const res = await fetch(`${API_URL}/animais`);
        const data = await res.json();
        setAnimais(data.dados || []);
    }

    async function loadZoologicos() {
        const res = await fetch(`${API_URL}/zoologicos`);
        const data = await res.json();
        setZoologicos(data.dados || []);
    }

    async function handleSubmit(e) {
        e.preventDefault();

        const method = form.id ? "PUT" : "POST";
        const url = form.id
            ? `${API_URL}/registros/${form.id}`
            : `${API_URL}/registros`;

        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                descricao: form.descricao,
                data: form.data,
                animal: Number(form.animal),
                zoologico: Number(form.zoologico)
            })
        });

        setForm({
            id: "",
            descricao: "",
            data: "",
            animal: "",
            zoologico: ""
        });

        loadRegistros();
    }

    function handleEdit(r) {
        setForm({
            id: r.id,
            descricao: r.descricao,
            data: r.data,
            animal: r.animal.id,
            zoologico: r.zoologico.id
        });
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    async function handleDelete(id) {
        if (!window.confirm("Excluir registro?")) return;
        await fetch(`${API_URL}/registros/${id}`, { method: "DELETE" });
        loadRegistros();
    }

    return (
        <>
            <style>{`
                body {
                    font-family: Arial;
                    background: #eceaff;
                    margin: 0;
                    padding: 20px;
                }
                .navbar {
                    background: white;
                    padding: 15px;
                    display: flex;
                    justify-content: space-between;
                    margin-bottom: 20px;
                    border-radius: 10px;
                }
                .navbar a {
                    margin-right: 15px;
                    text-decoration: none;
                    font-weight: bold;
                    color: #5a4ae3;
                }
                .card {
                    background: white;
                    padding: 25px;
                    border-radius: 12px;
                    margin-bottom: 20px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border-bottom: 1px solid #ddd;
                    padding: 10px;
                }
                th {
                    background: #f1f1ff;
                }
                .btn {
                    background: #5a4ae3;
                    color: white;
                    padding: 10px 15px;
                    border: none;
                    border-radius: 6px;
                    cursor: pointer;
                }
                .btn-edit {
                    background: #f5a623;
                    border: none;
                    color: white;
                    padding: 6px 10px;
                    border-radius: 5px;
                    cursor: pointer;
                }
                .btn-delete {
                    background: #d9534f;
                    border: none;
                    color: white;
                    padding: 6px 10px;
                    border-radius: 5px;
                    cursor: pointer;
                }
            `}</style>

            {/* NAVBAR */}
            <div className="navbar">
                <Link to="/">🏠 Início</Link>
                <div>
                    <Link to="/zoologico">Zoológicos</Link>
                    <Link to="/animal">Animais</Link>
                    <Link to="/produto">Produtos</Link>
                    <Link to="/fornecedor_alimento">Fornecedores</Link>
                    <Link to="/registro">Registros</Link>
                </div>
            </div>

            <div className="card">
                <h2>📝 Registrar Entrada</h2>

                <form onSubmit={handleSubmit}>
                    <div>
                        <label>Descrição *</label>
                        <input
                            required
                            value={form.descricao}
                            onChange={(e) => setForm({ ...form, descricao: e.target.value })}
                        />
                    </div>

                    <div>
                        <label>Data *</label>
                        <input
                            required
                            type="date"
                            value={form.data}
                            onChange={(e) => setForm({ ...form, data: e.target.value })}
                        />
                    </div>

                    <div>
                        <label>Animal *</label>
                        <select
                            required
                            value={form.animal}
                            onChange={(e) => setForm({ ...form, animal: e.target.value })}
                        >
                            <option value="">Selecione...</option>
                            {animais.map((a) => (
                                <option key={a.id} value={a.id}>
                                    {a.nome}
                                </option>
                            ))}
                        </select>
                    </div>

                    <div>
                        <label>Zoológico *</label>
                        <select
                            required
                            value={form.zoologico}
                            onChange={(e) =>
                                setForm({ ...form, zoologico: e.target.value })
                            }
                        >
                            <option value="">Selecione...</option>
                            {zoologicos.map((z) => (
                                <option key={z.id} value={z.id}>
                                    {z.nome}
                                </option>
                            ))}
                        </select>
                    </div>

                    <button className="btn">
                        {form.id ? "Atualizar Registro" : "Criar Registro"}
                    </button>
                </form>
            </div>

            <div className="card">
                <h2>📋 Registros Existentes</h2>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Descrição</th>
                            <th>Data</th>
                            <th>Animal</th>
                            <th>Zoológico</th>
                            <th>Ações</th>
                        </tr>
                    </thead>

                    <tbody>
                        {registros.map((r) => (
                            <tr key={r.id}>
                                <td>{r.id}</td>
                                <td>{r.descricao}</td>
                                <td>{r.data}</td>
                                <td>{r.animal?.nome}</td>
                                <td>{r.zoologico?.nome}</td>

                                <td>
                                    <button
                                        className="btn-edit"
                                        onClick={() => handleEdit(r)}
                                    >
                                        Editar
                                    </button>

                                    <button
                                        className="btn-delete"
                                        onClick={() => handleDelete(r.id)}
                                    >
                                        Excluir
                                    </button>
                                </td>
                            </tr>
                        ))}
                    </tbody>
                </table>
            </div>
        </>
    );
}
