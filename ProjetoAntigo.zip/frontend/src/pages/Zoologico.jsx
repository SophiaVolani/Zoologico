import React, { useEffect, useState } from "react";
import { Link } from "react-router-dom";

export default function Zoologico() {
    const API_URL = "http://localhost:5000";

    const [zoologicos, setZoologicos] = useState([]);
    const [form, setForm] = useState({
        id: "",
        nome: "",
        cep: "",
        capacidade: ""
    });

    useEffect(() => {
        loadZoologicos();
    }, []);

    async function loadZoologicos() {
        try {
            const res = await fetch(`${API_URL}/zoologicos`);
            const data = await res.json();
            setZoologicos(data.dados || []);
        } catch {
            console.error("Erro ao carregar zoológicos");
        }
    }

    async function handleSubmit(e) {
        e.preventDefault();

        const method = form.id ? "PUT" : "POST";
        const url = form.id
            ? `${API_URL}/zoologicos/${form.id}`
            : `${API_URL}/zoologicos`;

        await fetch(url, {
            method,
            headers: { "Content-Type": "application/json" },
            body: JSON.stringify({
                nome: form.nome,
                cep: form.cep,
                capacidade: Number(form.capacidade)
            })
        });

        setForm({ id: "", nome: "", cep: "", capacidade: "" });
        loadZoologicos();
    }

    function handleEdit(z) {
        setForm({
            id: z.id,
            nome: z.nome,
            cep: z.cep,
            capacidade: z.capacidade
        });
        window.scrollTo({ top: 0, behavior: "smooth" });
    }

    async function handleDelete(id) {
        if (!window.confirm("Excluir zoológico?")) return;

        await fetch(`${API_URL}/zoologicos/${id}`, { method: "DELETE" });
        loadZoologicos();
    }

    return (
        <>
            <style>{`
                body {
                    background: #e8e6ff;
                    margin: 0;
                    padding: 20px;
                    font-family: Arial;
                }
                .navbar {
                    background: white;
                    padding: 15px;
                    border-radius: 10px;
                    margin-bottom: 20px;
                    display: flex;
                    justify-content: space-between;
                }
                .navbar a {
                    margin-right: 15px;
                    text-decoration: none;
                    color: #4a42d1;
                    font-weight: bold;
                }
                .card {
                    background: white;
                    padding: 25px;
                    border-radius: 12px;
                    margin-bottom: 25px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.1);
                }
                table {
                    width: 100%;
                    border-collapse: collapse;
                }
                th, td {
                    border-bottom: 1px solid #ccc;
                    padding: 10px;
                    text-align: left;
                }
                th {
                    background: #f1f1ff;
                }
                input {
                    padding: 10px;
                    width: 100%;
                    margin-bottom: 10px;
                    border: 2px solid #ccc;
                    border-radius: 8px;
                }
                .btn {
                    background: #4a42d1;
                    color: white;
                    border: none;
                    padding: 10px 15px;
                    border-radius: 8px;
                    cursor: pointer;
                }
                .btn-edit {
                    background: #ffaf3f;
                    color: white;
                    border: none;
                    padding: 6px 10px;
                    margin-right: 5px;
                    border-radius: 6px;
                }
                .btn-delete {
                    background: #e44949;
                    color: white;
                    border: none;
                    padding: 6px 10px;
                    border-radius: 6px;
                }
            `}</style>

            {/* NAVBAR */}
            <div className="navbar">
                <Link to="/">🏠 Início</Link>
                <div>
                    <Link to="/animal">Animais</Link>
                    <Link to="/produto">Produtos</Link>
                    <Link to="/fornecedor_alimento">Fornecedores</Link>
                    <Link to="/registro">Registros</Link>
                </div>
            </div>

            <div className="card">
                <h2>🏛️ Gerenciamento de Zoológicos</h2>

                <form onSubmit={handleSubmit}>
                    <label>Nome *</label>
                    <input
                        required
                        value={form.nome}
                        onChange={(e) =>
                            setForm({ ...form, nome: e.target.value })
                        }
                    />

                    <label>CEP *</label>
                    <input
                        required
                        value={form.cep}
                        onChange={(e) =>
                            setForm({ ...form, cep: e.target.value })
                        }
                    />

                    <label>Capacidade *</label>
                    <input
                        required
                        type="number"
                        value={form.capacidade}
                        onChange={(e) =>
                            setForm({ ...form, capacidade: e.target.value })
                        }
                    />

                    <button className="btn">
                        {form.id ? "Atualizar Zoológico" : "Cadastrar Zoológico"}
                    </button>
                </form>
            </div>

            <div className="card">
                <h2>📋 Lista de Zoológicos</h2>

                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>CEP</th>
                            <th>Capacidade</th>
                            <th>Ações</th>
                        </tr>
                    </thead>

                    <tbody>
                        {zoologicos.length === 0 ? (
                            <tr>
                                <td colSpan="5" style={{ textAlign: "center" }}>
                                    Nenhum zoológico cadastrado
                                </td>
                            </tr>
                        ) : (
                            zoologicos.map((z) => (
                                <tr key={z.id}>
                                    <td>{z.id}</td>
                                    <td>{z.nome}</td>
                                    <td>{z.cep}</td>
                                    <td>{z.capacidade}</td>

                                    <td>
                                        <button
                                            className="btn-edit"
                                            onClick={() => handleEdit(z)}
                                        >
                                            Editar
                                        </button>

                                        <button
                                            className="btn-delete"
                                            onClick={() => handleDelete(z.id)}
                                        >
                                            Excluir
                                        </button>
                                    </td>
                                </tr>
                            ))
                        )}
                    </tbody>
                </table>
            </div>
        </>
    );
}
