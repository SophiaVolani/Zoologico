import React from "react";
import { BrowserRouter as Router, Routes, Route } from "react-router-dom";

import Home from "./Home";
import Zoologico from "./Zoologico";
import Animal from "./Animal";
import Produto from "./Produto";
import FornecedorAlimento from "./FornecedorAlimento";
import Registro from "./Registro";

export default function App() {
    return (
        <Router>
            <Routes>
                <Route path="/" element={<Home />} />

                <Route path="/zoologico" element={<Zoologico />} />

                <Route path="/animal" element={<Animal />} />

                <Route path="/produto" element={<Produto />} />

                <Route path="/fornecedor_alimento" element={<FornecedorAlimento />} />

                <Route path="/registro" element={<Registro />} />
            </Routes>
        </Router>
    );
}
